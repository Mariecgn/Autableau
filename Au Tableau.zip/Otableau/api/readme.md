# Gestion des Classes d'Étudiants

## Description

Cette application permet de gérer des classes d'étudiants et de suivre leurs passages en soutenance. Les utilisateurs peuvent créer des classes, ajouter des étudiants, et appeler des étudiants au tableau de manière aléatoire. Il est également possible de forcer un étudiant à passer. L'application utilise un stockage local pour gérer l'état de la soutenance.

## Fonctionnalités

- **Création de Classes** : Permet de créer des classes avec un nom spécifié.
- **Gestion des Étudiants** : Ajoutez, éditez ou supprimez des étudiants d'une classe spécifique.
- **Appel Aléatoire** : Un bouton pour appeler un étudiant au hasard pour la soutenance.
- **Forcer un Étudiant** : Possibilité de forcer un étudiant à passer au tableau.
- **Statistiques de Passage** : Visualisation des étudiants qui ont déjà passé et ceux qui doivent encore passer.
- **Gestion d'une Soutenance à la Fois** : Une seule soutenance peut être gérée à la fois.

## Contraintes

- Un étudiant ne peut appartenir qu'à une seule classe.
- Aucun étudiant ne peut être ajouté à une classe pendant qu'une soutenance est en cours.
- Un étudiant peut être appelé une seule fois pour passer au tableau.

## Technologies Utilisées

- HTML
- CSS (avec Bootstrap pour le style)
- JavaScript
- Local Storage pour la gestion de l'état

