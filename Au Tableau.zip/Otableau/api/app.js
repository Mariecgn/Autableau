const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const db = require('./db/db'); //importation de la configuration MySQL

const app = express();
const port = process.env.PORT || 5000;

app.use(cors()); //autoriser les requêtes du frontend
app.use(bodyParser.json()); //pour  lire le JSON

//servir les fichiers statiques du dossier "client"
app.use(express.static('client'));

//routes pour l'API
const classroomsRoutes = require('./routes/classrooms');
const studentsRoutes = require('./routes/students');
app.use('/classrooms', classroomsRoutes);
app.use('/classrooms/:classroom_id/students', studentsRoutes);

//demarrer le serveur
app.listen(port, () => {
    console.log(`Serveur en ligne sur le port ${port}`);
});
