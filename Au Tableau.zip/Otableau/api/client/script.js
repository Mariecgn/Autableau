// Sélection des éléments du DOM
const createClassButton = document.getElementById('createClassButton'); //btn pour créer une classe
const classSelect = document.getElementById('classSelect'); //selecteur des classes
const deleteClassButton = document.getElementById('deleteClassButton'); //btn pour supprimer une classe
const editClassButton = document.getElementById('editClassButton'); // btn pour modifier une classe (non utilisé ici)
const studentNameInput = document.getElementById('studentName'); // champ pour saisir le nom de l'étudiant
const addStudentButton = document.getElementById('addStudentButton'); // btn pour ajouter un étudiant
const studentsSection = document.getElementById('studentsSection'); // section contenant la liste des étudiants
const studentsList = document.getElementById('studentsList'); // liste des étudiants
const forceStudentSelect = document.getElementById('forceStudentSelect'); // selecteur pour forcer un étudiant à passer
const forceStudentButton = document.getElementById('forceStudentButton'); // btn pour forcer un étudiant
const forcedStudentMessage = document.getElementById('forcedStudentMessage'); // msg pour l'étudiant forcé
const randomStudentButton = document.getElementById('randomStudentButton'); // btn pour appeler un étudiant au hasard
const randomStudentMessage = document.getElementById('randomStudentMessage'); // msg pour l'étudiant appelé au hasard

//variables globales
let currentClassId = null; // ID de la classe sélectionnée
let passedStudents = []; // Liste des étudiants qui ont déjà été appelés
let forcedStudents = []; // Liste des étudiants forcés à passer

// fct pour récupérer les classes depuis l'API
async function fetchClasses() {
    const response = await fetch('http://localhost:5000/classrooms'); // query pour obtenir les classes
    const classes = await response.json();

    // remplir le sélecteur de classes
    classSelect.innerHTML = '<option value="">Sélectionner une classe</option>'; // optn par défaut
    classes.forEach(classItem => {
        const option = document.createElement('option');
        option.value = classItem.id; // utilise l'ID de la classe comme valeur
        option.textContent = classItem.name; // affiche le nom de la classe
        classSelect.appendChild(option);
    });
}

//fct pour recup les students d'une classe spécifique
async function fetchStudents(classId) {
    const response = await fetch(`http://localhost:5000/classrooms/${classId}/students`); // query pour obtenir les students
    const students = await response.json();

    // Réinitialiser la liste des students
    studentsList.innerHTML = '';
    forceStudentSelect.innerHTML = '<option value="">Sélectionner un étudiant</option>'; // Option par défaut
    students.forEach(student => {
        // créé un élément de liste pour chaque students
        const li = document.createElement('li');
        li.className = 'list-group-item d-flex justify-content-between align-items-center';
        li.textContent = student.name;

        // btn edit
        const editButton = document.createElement('button');
        editButton.className = 'btn btn-warning btn-sm ml-2';
        editButton.textContent = 'Modifier';
        editButton.onclick = () => editStudent(student.id); // fct d'edit

        // Bouton Supprimer
        const deleteButton = document.createElement('button');
        deleteButton.className = 'btn btn-danger btn-sm ml-2';
        deleteButton.textContent = 'Supprimer';
        deleteButton.onclick = () => deleteStudent(student.id); // fct de suppr

        li.appendChild(editButton); // ajt le btn edit à l'élément de liste
        li.appendChild(deleteButton); // ajt le btn suppr à l'élément de liste
        studentsList.appendChild(li); // ajt l'élément de liste à la liste des students

        // ajt le student au sélecteur pour forcer un student
        const option = document.createElement('option');
        option.value = student.id;
        option.textContent = student.name;
        forceStudentSelect.appendChild(option);
    });
}

// fct pour créer une nouvelle classe
async function createClass(className) {
    const response = await fetch('http://localhost:5000/classrooms', {
        method: 'POST', // query POST pour créer une classe
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name: className }) // send le nom de la classe
    });

    if (response.ok) {
        fetchClasses(); //maj de la liste des classes
    } else {
        alert('Erreur lors de la création de la classe.');
    }
}

// fct pour supprimer une classe
async function deleteClass(classId) {
    const response = await fetch(`http://localhost:5000/classrooms/${classId}`, {
        method: 'DELETE', // requete DELETE pour supprimer une classe
    });

    if (response.ok) {
        fetchClasses(); //maj des classes après suppression
        studentsSection.style.display = 'none'; // masquer la section des étudiants
    } else {
        alert('Erreur lors de la suppression de la classe.');
    }
}

//fct pour ajouter un étudiant à une classe
async function addStudent(classId, studentName) {
    const response = await fetch(`http://localhost:5000/classrooms/${classId}/students`, {
        method: 'POST', // requete POST pour ajouter un étudiant
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name: studentName }) // send le nom de l'étudiant
    });

    if (response.ok) {
        studentNameInput.value = ''; // reinit le champ
        fetchStudents(classId); // maj de la liste des étudiants
    } else {
        // gerer les erreurs lors de l'ajout d'un étudiant
        if (response.status == 400) {
            alert("L'étudiant est déjà inscrit dans une autre classe");
        } else {
            alert("ATTENTION : l'étudiant est déjà dans une classe !");
        }
    }
}

// fct pour supprimer un étudiant
async function deleteStudent(studentId) {
    const response = await fetch(`http://localhost:5000/classrooms/${currentClassId}/students/${studentId}`, {
        method: 'DELETE', // requete DELETE pour supprimer un étudiant
    });

    if (response.ok) {
        fetchStudents(currentClassId); // maj de la liste après suppression
    } else {
        alert('Erreur lors de la suppression de l\'étudiant.');
    }
}

// fct pour éditer un étudiant
async function editStudent(studentId) {
    const newName = prompt('Entrez le nouveau nom de l\'étudiant :'); // demande du nouveau nom
    if (newName) {
        const response = await fetch(`http://localhost:5000/classrooms/${currentClassId}/students/${studentId}`, {
            method: 'PUT', // requete PUT pour modifier l'étudiant
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name: newName }) // send le nouveau nom
        });

        if (response.ok) {
            fetchStudents(currentClassId); // maj de la liste après modification
        } else {
            alert('Erreur lors de la modification de l\'étudiant.');
        }
    }
}

// events pour les boutons et interactions
createClassButton.addEventListener('click', () => {
    const className = document.getElementById('className').value;
    if (className) {
        createClass(className); // crée une classe si le nom est fourni
        document.getElementById('className').value = ''; // réinit le champ de saisie
    } else {
        alert('Veuillez entrer un nom de classe.');
    }
});

classSelect.addEventListener('change', (e) => {
    currentClassId = e.target.value; //maj l'ID de la classe sélectionnée
    if (currentClassId) {
        studentsSection.style.display = 'block'; // afficher la section des students
        fetchStudents(currentClassId); // recup les students de la classe sélectionnée
        document.getElementById('forceStudentSection').style.display = 'block'; // afficher la section pour forcer un student
    } else {
        studentsSection.style.display = 'none'; // masque la section des students si aucune classe n'est sélectionnée
        document.getElementById('forceStudentSection').style.display = 'none'; // Masquer la section pour forcer un student
    }
});

// event pour ajouter un student
addStudentButton.addEventListener('click', () => {
    const studentName = studentNameInput.value;
    if (studentName && currentClassId) {
        addStudent(currentClassId, studentName); // ajt un student si les champs sont remplis
    } else {
        alert('Veuillez entrer un nom d\'étudiant et sélectionner une classe.');
    }
});

//event pour forcer un étudiant à être appelé
forceStudentButton.addEventListener('click', () => {
    const studentId = forceStudentSelect.value;
    if (studentId) {
        const studentName = forceStudentSelect.options[forceStudentSelect.selectedIndex].text; // Récupérer le nom du student
        if (!passedStudents.includes(studentId)) {
            forcedStudents.push(studentId); //ajt student à la liste des students à forcer
            forcedStudentMessage.textContent = `${studentName} doit passer obligatoirement.`;
            passedStudents.push(studentId); //ajouter le student à la liste des passés
        } else {
            alert(`${studentName} est déjà passé !`);
        }
    } else {
        alert('Veuillez sélectionner un étudiant à passer au tableau.');
    }
});

// event pour appeler un student au hasard
randomStudentButton.addEventListener('click', () => {
    fetch(`http://localhost:5000/classrooms/${currentClassId}/students`)
        .then(response => response.json())
        .then(students => {
            // filtre les student qui ne sont pas encore passé
            const availableStudents = students.filter(student => !passedStudents.includes(student.id) && !forcedStudents.includes(student.id));
            if (availableStudents.length > 0) {
                const randomIndex = Math.floor(Math.random() * availableStudents.length);
                const selectedStudent = availableStudents[randomIndex];
                randomStudentMessage.textContent = `${selectedStudent.name} a été appelé au tableau.`; // affiche l'étudiant appeler
                passedStudents.push(selectedStudent.id); // marquer l'étudiant comme ayant passé
            } else {
                randomStudentMessage.textContent = 'Tous les étudiants sont déjà passés.'; // msg si tous les étudiants ont passé
            }
        })
        .catch(error => {
            console.error('Erreur:', error);
        });
});

// event pour supprimer une classe
deleteClassButton.addEventListener('click', () => {
    if (currentClassId) {
        deleteClass(currentClassId); //delete la classe sélectionnée
    } else {
        alert('Veuillez sélectionner une classe à supprimer.');
    }
});

//initialiser la liste des classes au chargement de la page
fetchClasses();
