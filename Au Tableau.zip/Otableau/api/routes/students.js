const express = require('express');
const db = require('../db/db');
const router = express.Router({ mergeParams: true }); //fusionne les paramètres de route, donc classroom_id

// recup la liste des étudiants dans une classe
router.get('/', (req, res) => {
    const classroomId = req.params.classroom_id; // Récupère l'ID de la classe à partir des paramètres d'URL
    db.query('SELECT * FROM students WHERE classroom_id = ?', [classroomId], (err, results) => { // exct une requête sql pour obtenir tous les étudiants d'une classe
        if (err) return res.status(500).json({ error: err.message }); // Gère les erreurs de la requête SQL
        res.json(results); // renvoie la liste des étudiants sous forme de JSON
    });
});

// ajt un étudiant à une classe
router.post('/', (req, res) => {
    const classroomId = req.params.classroom_id; // recup l'ID de la classe
    const { name } = req.body; // recup le nom de l'étudiant depuis la requête POST
    if (!name) return res.status(422).json({ error: 'Il manque le paramètre "name"' }); // verif si le nom est fourni, sinon renvoie une erreur

    // verif si l'étudiant existe déjà dans la base de données
    db.query('SELECT * FROM students WHERE name = ?', [name], (err, results) => {
        if (err) return res.status(500).json({ error: err.message }); // gere les erreurs SQL
        if (results.length > 0) return res.status(409).json({ error: 'L\'étudiant existe déjà dans la classe' }); // Si un étudiant existe déjà dans la même classe, renvoie une erreur

        // si l'étudiant n'existe pas encore, l'ajoute dans la base de données avec l'ID de la classe associée
        db.query('INSERT INTO students (name, classroom_id) VALUES (?, ?)', [name, classroomId], (err) => {
            if (err) return res.status(500).json({ error: err.message }); // gere les erreurs lors de l'insertion
            res.status(201).json({ message: 'Étudiant ajouté avec succès' }); // Confirme l'ajt avec succès
        });
    });
});

// delete un étudiant
router.delete('/:student_id', (req, res) => {
    const { student_id } = req.params; // recup l'ID de l'étudiant à supprimer à partir des paramètres d'URL

    // exect une requête SQL pour supprimer l'étudiant par ID
    db.query('DELETE FROM students WHERE id = ?', [student_id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message }); //gere les erreurs SQL
        if (results.affectedRows === 0) return res.status(404).json({ error: 'L\'étudiant n\'existe pas' }); //si aucun étudiant n'a été supprimé, cela signifie que l'étudiant n'existe pas
        res.status(204).send(); // Renvoie une réponse vide indiquant la suppression réussie
    });
});

// modif un étudiant
router.put('/:student_id', (req, res) => {
    const { student_id } = req.params; // recup l'ID de l'étudiant à modifier
    const { name } = req.body; // recup le nouveau nom de l'étudiant depuis le corps de la requête

    if (!name) return res.status(422).json({ error: 'Il manque le paramètre "name"' }); // verif que le nouveau nom est fourni

    // exct une requête SQL pour mettre à jour le nom de l'étudiant
    db.query('UPDATE students SET name = ? WHERE id = ?', [name, student_id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message }); // gere les erreurs SQL
        if (results.affectedRows === 0) return res.status(404).json({ error: 'L\'étudiant n\'existe pas' }); // si aucune ligne n'a été modifiée, l'étudiant n'existe pas
        res.status(200).json({ message: 'Étudiant modifié avec succès' }); // confirme la modification avec succès
    });
});

module.exports = router; // exporte le routeur pour qu'il puisse être utilisé dans d'autres parties de l'application
