const express = require('express');
const db = require('../db/db');
const router = express.Router();

// Récupérer la liste des classes
router.get('/', (req, res) => {
    db.query('SELECT * FROM classrooms', (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// Créer une classe
router.post('/', (req, res) => {
    const { name } = req.body;
    if (!name) return res.status(422).json({ error: 'Il manque le paramètre "name"' });

    db.query('SELECT * FROM classrooms WHERE name = ?', [name], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (results.length > 0) return res.status(409).json({ error: 'Le paramètre "name" existe déjà' });

        db.query('INSERT INTO classrooms (name) VALUES (?)', [name], (err) => {
            if (err) return res.status(500).json({ error: err.message });
            res.status(201).json({ message: 'Classe créée avec succès' });
        });
    });
});

// Supprimer une classe
router.delete('/:id', (req, res) => {
    const { id } = req.params;

    db.query('DELETE FROM classrooms WHERE id = ?', [id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (results.affectedRows === 0) return res.status(404).json({ error: 'La classe n\'existe pas' });
        res.status(204).send();
    });
});

// Modifier une classe
router.put('/:id', (req, res) => {
    const { id } = req.params;
    const { name } = req.body;

    if (!name) return res.status(422).json({ error: 'Il manque le paramètre "name"' });

    db.query('UPDATE classrooms SET name = ? WHERE id = ?', [name, id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (results.affectedRows === 0) return res.status(404).json({ error: 'La classe n\'existe pas' });
        res.status(200).json({ message: 'Classe modifiée avec succès' });
    });
});

module.exports = router;
